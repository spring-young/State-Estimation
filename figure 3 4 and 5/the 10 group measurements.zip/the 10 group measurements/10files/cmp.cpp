#include <iostream>
#include <fstream>
#include <math.h>
#include <string.h>
#include <cstdlib>
#include <iomanip>
#include <map>
using namespace std;

int main(int argc,char **argv)
{
	int i_v,i_t,k;
	int N;
	int Num=0;
	double max_v[6],max_t[6],avg_v[6],avg_t[6];
	double volt,theta,volt2,theta2;
	double maxv,maxt,avgv,avgt;	
	double tempv,tempt;
	map<double,int>voltage,angle;
	map<double,int>::iterator iter;
	fstream infile,infile2;
	N = atoi(argv[1]);
	//kd
	infile.open("true.txt",ios::in);
	infile2.open("kd3.txt",ios::in);
	maxv=0.0;
	maxt=0.0;
	avgv=0.0;
	avgt=0.0;
	for(k=1;k<=N;k++)
	{
		infile>>volt>>theta;
		infile2>>volt2>>theta2;
		tempv=fabs(volt2-volt);
		tempt=fabs(theta2-theta);
		if (tempv>maxv) maxv=tempv;
		if (tempt>maxt) maxt=tempt;
		avgv+=tempv;
		avgt+=tempt;
	}
	avgv/=N;
	avgt/=N;
	max_v[1]=maxv;
	max_t[1]=maxt;
	avg_v[1]=avgv;
	avg_t[1]=avgt;
	infile.close();
	infile2.close();
	//meav
	infile.open("true.txt",ios::in);
	infile2.open("meav.txt",ios::in);
	maxv=0.0;
	maxt=0.0;
	avgv=0.0;
	avgt=0.0;
	for(k=1;k<=N;k++)
	{
		infile>>volt>>theta;
		infile2>>volt2>>theta2;
		tempv=fabs(volt2-volt);
		tempt=fabs(theta2-theta);
		if (tempv>maxv) maxv=tempv;
		if (tempt>maxt) maxt=tempt;
		avgv+=tempv;
		avgt+=tempt;
	}
	avgv/=N;
	avgt/=N;
	max_v[2]=maxv;
	max_t[2]=maxt;
	avg_v[2]=avgv;
	avg_t[2]=avgt;
	infile.close();
	infile2.close();
	//mes
	infile.open("true.txt",ios::in);
	infile2.open("mes.txt",ios::in);
	maxv=0.0;
	maxt=0.0;
	avgv=0.0;
	avgt=0.0;
	for(k=1;k<=N;k++)
	{
		infile>>volt>>theta;
		infile2>>volt2>>theta2;
		tempv=fabs(volt2-volt);
		tempt=fabs(theta2-theta);
		if (tempv>maxv) maxv=tempv;
		if (tempt>maxt) maxt=tempt;
		avgv+=tempv;
		avgt+=tempt;
	}
	avgv/=N;
	avgt/=N;
	max_v[3]=maxv;
	max_t[3]=maxt;
	avg_v[3]=avgv;
	avg_t[3]=avgt;
	infile.close();
	infile2.close();
	infile.open("true.txt",ios::in);
	infile2.open("wlav.txt",ios::in);
	maxv=0.0;
	maxt=0.0;
	avgv=0.0;
	avgt=0.0;
	for(k=1;k<=N;k++)
	{
		infile>>volt>>theta;
		infile2>>volt2>>theta2;
		tempv=fabs(volt2-volt);
		tempt=fabs(theta2-theta);
		if (tempv>maxv) maxv=tempv;
		if (tempt>maxt) maxt=tempt;
		avgv+=tempv;
		avgt+=tempt;
	}
	avgv/=N;
	avgt/=N;
	max_v[4]=maxv;
	max_t[4]=maxt;
	avg_v[4]=avgv;
	avg_t[4]=avgt;
	infile.close();
	infile2.close();
	infile.open("true.txt",ios::in);
	infile2.open("igg.txt",ios::in);
	maxv=0.0;
	maxt=0.0;
	avgv=0.0;
	avgt=0.0;
	for(k=1;k<=N;k++)
	{
		infile>>volt>>theta;
		infile2>>volt2>>theta2;
		tempv=fabs(volt2-volt);
		tempt=fabs(theta2-theta);
		if (tempv>maxv) maxv=tempv;
		if (tempt>maxt) maxt=tempt;
		avgv+=tempv;
		avgt+=tempt;
	}
	avgv/=N;
	avgt/=N;
	max_v[5]=maxv;
	max_t[5]=maxt;
	avg_v[5]=avgv;
	avg_t[5]=avgt;
	infile.close();
	infile2.close();
	for(k=1;k<=5;k++)
	{
		voltage[max_v[k]]=k;
		angle[max_t[k]]=k;
	}
	cout<<"AKDE"<<"\t"<<"MEAV"<<"\t"<<"MES"<<"\t"<<"WLAV"<<"\t"<<"IGG"<<endl;
	cout<<fixed<<setprecision(5)<<max_v[1]<<"\t"<<fixed<<setprecision(5)<<max_v[2]<<"\t"<<fixed<<setprecision(5)<<max_v[3]<<"\t"<<fixed<<setprecision(5)<<max_v[4]<<"\t"<<fixed<<setprecision(5)<<max_v[5]<<endl;
	cout<<fixed<<setprecision(5)<<max_t[1]<<"\t"<<fixed<<setprecision(5)<<max_t[2]<<"\t"<<fixed<<setprecision(5)<<max_t[3]<<"\t"<<fixed<<setprecision(5)<<max_t[4]<<"\t"<<fixed<<setprecision(5)<<max_t[5]<<endl;
	cout<<"voltage:";
	for(iter=voltage.begin();iter!=voltage.end();iter++)
	{
		cout<<iter->second<<"->";
	}
	cout<<endl;
	cout<<"angle  :";
	for(iter=angle.begin();iter!=angle.end();iter++)
	{
		cout<<iter->second<<"->";
	}
	cout<<endl;
	voltage.clear();
	angle.clear();
	/*i_v=i_t=1;
	maxv=max_v[1];
	maxt=max_v[1];
	for(k=2;k<=5;k++)
	{
		if (max_v[k]<maxv)
		{
			maxv = max_v[k];
			i_v = k;
		}
		if (max_t[k]<maxt)
		{
			maxt = max_t[k];
			i_t = k;
		}
	}
	cout<<"min algorithm for voltage and angle are: "<<i_v<<"\t"<<i_t<<endl;*/
	for(k=1;k<=5;k++)
	{
		voltage[avg_v[k]]=k;
		angle[avg_t[k]]=k;
	}
	cout<<"AKDE"<<"\t"<<"MEAV"<<"\t"<<"MES"<<"\t"<<"WLAV"<<"\t"<<"IGG"<<endl;
	cout<<fixed<<setprecision(5)<<avg_v[1]<<"\t"<<fixed<<setprecision(5)<<avg_v[2]<<"\t"<<fixed<<setprecision(5)<<avg_v[3]<<"\t"<<fixed<<setprecision(5)<<avg_v[4]<<"\t"<<fixed<<setprecision(5)<<avg_v[5]<<endl;
	cout<<fixed<<setprecision(5)<<avg_t[1]<<"\t"<<fixed<<setprecision(5)<<avg_t[2]<<"\t"<<fixed<<setprecision(5)<<avg_t[3]<<"\t"<<fixed<<setprecision(5)<<avg_t[4]<<"\t"<<fixed<<setprecision(5)<<avg_t[5]<<endl;
	cout<<"voltage: ";
	for(iter=voltage.begin();iter!=voltage.end();iter++)
	{
		cout<<iter->second<<"->";
	}
	cout<<endl;
	cout<<"angle  : ";
	for(iter=angle.begin();iter!=angle.end();iter++)
	{
		cout<<iter->second<<"->";
	}
	cout<<endl;
	voltage.clear();
	angle.clear();
	/*i_v=i_t=1;
	maxv=max_v[1];
	maxt=max_v[1];
	for(k=2;k<=5;k++)
	{
		if (avg_v[k]<maxv)
		{
			maxv = avg_v[k];
			i_v = k;
		}
		if (avg_t[k]<maxt)
		{
			maxt = avg_t[k];
			i_t = k;
		}
	}
	cout<<"min algorithm for voltage and angle are: "<<i_v<<"\t"<<i_t<<endl;*/
	return 0;
}
